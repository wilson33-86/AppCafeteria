<?php
header("Location: productos.php");
