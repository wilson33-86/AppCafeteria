# aplicación cafeteria realizada PHp,Msqli,Boostrap

La aplicación se realizo en Php nativo Version 7.3.33, base de datos mysql,
cree 4 tablas que son productos, categoria,factura, facturaDetalle,
En index se puede hacer todo el crud de productos, en la opcion catalogo se puede realizar una compra por producto y se aplicaron todos requerimientos solicitados.
